from django.urls import path, reverse_lazy
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    # Vistas de Autenticación
    path('registro/', views.registro_usuario, name='registro'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    # URLs de Logout
    path('logout/', RedirectView.as_view(url=reverse_lazy('logout_confirm')), name='logout'),
    path('logout/confirm/', views.logout_confirm, name='logout_confirm'),
    path('logout/perform/', views.logout_perform, name='logout_perform'),
    
    # Vistas AJAX
    path('ajax/cargar-comunas/', views.cargar_comunas, name='cargar_comunas'),
    
    # Vistas Principales
    path('', views.principal, name='principal'),
    
    # PERFIL (CORREGIDO: Usamos perfil_detalle y perfil_editar)
    path('perfil/', views.perfil_detalle, name='perfil_detalle'), 
    path('perfil/editar/', views.perfil_editar, name='perfil_editar'), 
    
    # VISTAS DE DIRECTORIOS
    path('directorio/proveedores/', views.directorio_proveedores, name='directorio_proveedores'),
    path('directorio/comercios/', views.directorio_comercios, name='directorio_comercios'),
    
    # VISTAS DEL FORO 
    path('foro/', views.foros_lista, name='foros_lista'), 
    path('foro/crear/', views.foro_crear, name='foro_crear'), 
    path('foro/detalle/<int:tema_id>/', views.foro_detalle, name='foro_detalle'),
    
    # VISTAS DE SOPORTE Y ADMINISTRACIÓN
    path('soporte/crear/', views.soporte_crear, name='soporte_crear'),
    
    # URLs de Administración Técnica / Super Admin
    path('gestion/usuarios/', views.admin_usuarios, name='admin_usuarios'),
    path('gestion/mantenimiento/', views.mantenimiento_logs, name='mantenimiento_logs'),
    path('gestion/global/config/', views.configuracion_global, name='configuracion_global'),
    path('gestion/usuario/editar/<int:user_id>/', views.usuario_editar, name='usuario_editar'),
    path('gestion/usuario/estado/<int:user_id>/<str:action>/', views.usuario_activar_desactivar, name='usuario_activar_desactivar'),
    path('gestion/tickets/', views.gestion_tickets, name='gestion_tickets'),
    path('gestion/tickets/<int:ticket_id>/', views.ticket_detalle, name='ticket_detalle'),

    # URLs de Administración Regional
    path('gestion/regional/reportes/', views.reportes_regionales, name='reportes_regionales'),
    path('gestion/regional/monitoreo/', views.monitoreo_comercios, name='monitoreo_comercios'),

    # URLs de Ofertas <-- ¡NUEVO!
    path('ofertas/', views.oferta_lista, name='ofertas_lista'),
    path('ofertas/publicar/', views.ofertas_publicar, name='ofertas_publicar'),
]