from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.views import LoginView
from django.contrib import messages
from django.conf import settings
from django.http import JsonResponse
from django.urls import reverse_lazy
import datetime
from django.utils import timezone
from django.db.models import Count 
from django.db.models import Q
from django.core.exceptions import PermissionDenied
from .models import User, Region, Comuna, TemaForo, RespuestaForo, TicketSoporte
from .forms import PerfilEdicionForm, RegistroUsuarioForm, TemaForoForm, RespuestaForoForm, OfertaForm, OfertaProveedor, TicketForm, TicketGestionForm


# --- VISTAS DE AUTENTICACIÓN ---

class CustomLoginView(LoginView):
    template_name = 'registro/login.html'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return reverse_lazy('principal')

def logout_confirm(request):
    return render(request, 'registro/logout_confirm.html')

@login_required
def logout_perform(request):
    logout(request)
    messages.info(request, "Has cerrado sesión correctamente.")
    return redirect(settings.LOGOUT_REDIRECT_URL)


def registro_usuario(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, '¡Registro exitoso! Por favor, inicia sesión.')
            return redirect('login')
        else:
            if 'region_aux' in request.POST:
                try:
                    region_id = request.POST.get('region_aux')
                    region = Region.objects.get(pk=region_id)
                    form.fields['comuna'].queryset = Comuna.objects.filter(region=region).order_by('nombre')
                except Region.DoesNotExist:
                    pass
    else:
        form = RegistroUsuarioForm()
        
    return render(request, 'registro/registro.html', {'titulo': 'Registro de Usuario', 'form': form})


# --- VISTAS AJAX ---

def cargar_comunas(request):
    """Endpoint AJAX para cargar las comunas según la región seleccionada."""
    region_id = request.GET.get('region_id')
    
    if not region_id or region_id == '':
        return JsonResponse([{'id': '', 'nombre': '---------'}], safe=False)
        
    try:
        comunas = Comuna.objects.filter(region_id=region_id).order_by('nombre')
    except Exception:
        comuna_list = []
    else:
        comuna_list = [{'id': comuna.id, 'nombre': comuna.nombre} for comuna in comunas]
        
    comuna_list.insert(0, {'id': '', 'nombre': '---------'})
    return JsonResponse(comuna_list, safe=False)


# --- VISTAS PRINCIPALES ---

def principal(request):
    """Dashboard principal. Define el template del slider basado en el rol."""
    user = request.user
    
    slider_template = 'sliders/slider_base.html'
    
    if user.is_authenticated:
        if user.tipo_usuario == 'comerciante':
            slider_template = 'sliders/slider_comerciante.html'
        elif user.tipo_usuario == 'proveedor':
            slider_template = 'sliders/slider_proveedor.html'
        elif user.is_staff:
             slider_template = 'sliders/slider_admin.html'

    context = {
        'nombre_completo': user.get_full_name() if user.is_authenticated else 'Invitado',
        'rol': user.get_tipo_usuario_display() if user.is_authenticated else 'Anónimo', 
        'is_authenticated': user.is_authenticated,
        'slider_template': slider_template,
    }
    return render(request, 'principal.html', context)


# --- VISTAS DE PERFIL ---

@login_required
def perfil_detalle(request):
    """Muestra los datos del perfil del usuario (Vista de lectura)."""
    context = {
        'titulo': 'Mi Perfil',
        'user_data': request.user 
    }
    return render(request, 'perfil/perfil_detalle.html', context)


@login_required
def perfil_editar(request):
    """Permite al usuario editar su perfil (Vista de escritura)."""
    user = request.user
    
    if request.method == 'POST':
        form = PerfilEdicionForm(request.POST, instance=user) 
        if form.is_valid():
            form.save() 
            messages.success(request, '¡Perfil actualizado exitosamente!')
            return redirect('perfil_detalle') 
        else:
            messages.error(request, 'Error al guardar los cambios. Revisa los campos marcados.')
    else:
        form = PerfilEdicionForm(instance=user)
    
    context = {
        'titulo': 'Editar Mi Perfil',
        'form': form
    }
    return render(request, 'perfil/perfil_editar.html', context)


# --- VISTAS DE DIRECTORIOS ---

def directorio_proveedores(request):
    """Muestra la lista de proveedores."""
    proveedores_list = User.objects.filter(tipo_usuario='proveedor', is_active=True).order_by('first_name')
    
    context = {
        'proveedores': proveedores_list,
        'titulo': 'Directorio de Proveedores',
    }
    return render(request, 'directorio/directorio_proveedores.html', context)


@login_required
def directorio_comercios(request):
    """Muestra la lista de comercios."""
    comercios_list = User.objects.filter(tipo_usuario='comerciante', is_active=True).order_by('first_name')
    
    context = {
        'comercios': comercios_list,
        'titulo': 'Directorio de Comercios',
    }
    return render(request, 'directorio/directorio_comercios.html', context) 

def is_proveedor(user):
    """Decorador auxiliar para verificar el rol."""
    return user.is_authenticated and user.tipo_usuario == 'proveedor'

@login_required
@user_passes_test(is_proveedor, login_url='/') 
def ofertas_publicar(request):
    """Permite a los proveedores publicar una nueva oferta."""
    if request.method == 'POST':
        form = OfertaForm(request.POST, request.FILES)
        if form.is_valid():
            oferta = form.save(commit=False)
            oferta.proveedor = request.user 
            oferta.save()
            messages.success(request, '¡Oferta publicada exitosamente!')
            return redirect('ofertas_lista')
    else:
        form = OfertaForm()
        
    return render(request, 'ofertas/ofertas_publicar.html', {'titulo': 'Publicar Nueva Oferta', 'form': form})

def oferta_lista(request):
    """Muestra la lista de ofertas con filtros de región/comuna."""
    
    ofertas_queryset = OfertaProveedor.objects.filter(
        fecha_expiracion__gte=timezone.now().date()
    )

    region_id = request.GET.get('region')
    comuna_id = request.GET.get('comuna')

    if comuna_id:
        ofertas_queryset = ofertas_queryset.filter(proveedor__comuna_id=comuna_id)
    elif region_id:
        ofertas_queryset = ofertas_queryset.filter(proveedor__region_id=region_id)

    todas_las_regiones = Region.objects.all().order_by('nombre')
    context = {
        'titulo': 'Ofertas Disponibles',
        'ofertas': ofertas_queryset,
        'regiones': todas_las_regiones,
    }
    
    return render(request, 'ofertas/oferta_lista.html', context)

# --- VISTAS DEL FORO ---

def foros_lista(request):
    """Muestra la lista de temas del foro, con conteo de respuestas optimizado."""
    temas = TemaForo.objects.all() \
        .annotate(num_respuestas=Count('respuestaforo')) \
        .order_by('-fecha_creacion')
        
    return render(request, 'foro/foros_lista.html', {'titulo': 'Foro de la Comunidad', 'temas': temas})

@login_required
def foro_crear(request):
    if request.method == 'POST':
        form = TemaForoForm(request.POST, request.FILES)
        if form.is_valid():
            tema = form.save(commit=False)
            tema.autor = request.user
            tema.save()
            messages.success(request, 'Tema creado exitosamente.')
            return redirect('foros_lista') 
    else:
        form = TemaForoForm()
        
    return render(request, 'foro/foro_crear.html', {'titulo': 'Crear Tema', 'form': form})

def foro_detalle(request, tema_id):
    tema = get_object_or_404(TemaForo, id=tema_id)
    respuestas = RespuestaForo.objects.filter(tema=tema).order_by('fecha_creacion')
    
    if request.method == 'POST':
        form = RespuestaForoForm(request.POST)
        if form.is_valid():
            respuesta = form.save(commit=False)
            respuesta.autor = request.user
            respuesta.tema = tema
            respuesta.save()
            messages.success(request, 'Respuesta publicada exitosamente.')
            return redirect('foro_detalle', tema_id=tema.id) 
    else:
        form = RespuestaForoForm()
        
    context = {
        'titulo': tema.titulo, 'tema': tema, 'respuestas': respuestas, 'form': form,
    }
    return render(request, 'foro/foro_detalle.html', context)


# --- DECORADORES AUXILIARES ---

def is_admin_tecnico_or_super(user):
    """Verifica si el usuario es super_admin o admin_tecnico."""
    return user.is_authenticated and (user.tipo_usuario == 'super_admin' or user.tipo_usuario == 'admin_tecnico')

ADMIN_ROLES = ['super_admin', 'admin_tecnico', 'admin_regional']

# --- VISTAS DE SOPORTE Y ADMINISTRACIÓN ---

ADMIN_TECNICO_ROLES = ['admin_tecnico', 'super_admin']
ADMIN_REGIONAL_ROLES = ['admin_regional']

@login_required
def soporte_crear(request):
    """
    Si es un Administrador: Redirige al panel de gestión de tickets.
    Si es un usuario regular: Muestra el formulario de creación de ticket.
    """
    user = request.user

    # --- Lógica de Redirección para Administradores ---
    if user.tipo_usuario in ['admin_tecnico', 'super_admin', 'admin_regional']:
        messages.info(request, "Redirigido a la gestión central de Tickets de Soporte.")
        return redirect('gestion_tickets') # Redirige a la nueva vista de gestión
    
    # --- Lógica para Creación de Ticket (Comerciante/Proveedor) ---
    
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.usuario = user
            ticket.save()
            
            messages.success(request, '¡Ticket de soporte creado! Un administrador se pondrá en contacto pronto.')
            return redirect('principal') 
        else:
            messages.error(request, 'Hubo un error al enviar el ticket. Revisa los campos.')
    else:
        form = TicketForm()
        
    context = {
        'titulo': 'Crear Ticket de Soporte',
        'form': form
    }
    return render(request, 'soporte/soporte_crear.html', context)


@login_required
def gestion_tickets(request):
    """
    Vista para que los Administradores vean y gestionen tickets pendientes.
    """
    user = request.user
    
    # Solo los roles de Admin pueden ver esto
    if user.tipo_usuario not in ['super_admin', 'admin_tecnico', 'admin_regional']:
        raise PermissionDenied("No tienes permiso para acceder a la gestión de tickets.")
    
    tickets_queryset = TicketSoporte.objects.filter(estado='pendiente')
    
    # Filtrado por rol y/o región
    if user.tipo_usuario in ['super_admin', 'admin_tecnico']:
        # Admins centrales ven todos los pendientes
        tickets_queryset = tickets_queryset.order_by('fecha_creacion')
        
    elif user.tipo_usuario == 'admin_regional':
        # Admin regional ve tickets de su región O tickets asignados directamente a él
        if user.region:
             tickets_queryset = TicketSoporte.objects.filter(
                Q(estado='pendiente') & 
                (
                    Q(usuario__region=user.region) | 
                    Q(admin_asignado=user)
                )
            ).distinct().order_by('fecha_creacion')
        else:
             # Si el Admin Regional no tiene región asignada, solo ve los que tiene asignados
             tickets_queryset = tickets_queryset.filter(admin_asignado=user).order_by('fecha_creacion')


    context = {
        'titulo': 'Gestión de Tickets de Soporte',
        'tickets': tickets_queryset,
    }
    # Asegúrate de crear este template: administracion/gestion_tickets.html
    return render(request, 'administracion/gestion_tickets.html', context)

@login_required
def ticket_detalle(request, ticket_id):
    """
    Vista para ver el detalle de un ticket y permitir a los administradores
    cambiar su estado y reasignarlo.
    """
    user = request.user
    
    # 1. Permiso: Solo los roles de Admin pueden ver esto
    if user.tipo_usuario not in ['super_admin', 'admin_tecnico', 'admin_regional']:
        raise PermissionDenied("No tienes permiso para acceder a la gestión de tickets.")

    # 2. Obtener Ticket
    ticket = get_object_or_404(TicketSoporte, id=ticket_id)
    
    # 3. Restricción Regional (Opcional pero recomendable)
    if user.tipo_usuario == 'admin_regional':
        es_su_region = (user.region and ticket.usuario.region == user.region)
        es_su_asignacion = (ticket.admin_asignado == user)
        
        # Si no es Super Admin/Admin Técnico, y no cumple con los criterios
        if not (es_su_region or es_su_asignacion or ticket.estado == 'cerrado'):
             messages.error(request, "No tienes permiso para gestionar este ticket fuera de tu región o asignación.")
             return redirect('gestion_tickets')

    # 4. Procesar Formulario de Gestión (POST)
    if request.method == 'POST':
        form = TicketGestionForm(request.POST, instance=ticket)
        if form.is_valid():
            
            # Lógica de auto-asignación al tomar el ticket
            if ticket.estado == 'pendiente' and form.cleaned_data['estado'] == 'en_progreso' and not ticket.admin_asignado:
                ticket.admin_asignado = user
                messages.info(request, f"Ticket #{ticket.id} tomado automáticamente por {user.get_full_name()}.")
            
            form.save()
            messages.success(request, f'Ticket #{ticket.id} ha sido actualizado correctamente. Estado: {ticket.get_estado_display()}')
            
            # Si se cerró el ticket, el admin regional puede volver a la lista de pendientes
            if form.cleaned_data['estado'] == 'cerrado':
                return redirect('gestion_tickets')
            
            # Si solo se modificó la asignación/estado, recarga la página para ver el cambio
            return redirect('ticket_detalle', ticket_id=ticket.id) 
        else:
            messages.error(request, 'Hubo un error al actualizar el ticket. Revise el formulario.')
    
    # 5. Mostrar Formulario (GET)
    else:
        # Pasa la instancia del ticket al formulario para pre-llenar los datos actuales
        form = TicketGestionForm(instance=ticket) 
        
    context = {
        'titulo': f'Detalle y Gestión de Ticket #{ticket.id}',
        'ticket': ticket,
        'form': form,
        'gestionando_admin': user,
    }
    return render(request, 'administracion/ticket_detalle.html', context)

# VISTAS DE ADMINISTRACIÓN TÉCNICA / SUPER ADMIN

@login_required
@user_passes_test(is_admin_tecnico_or_super, login_url='/') 
def admin_usuarios(request):
    usuarios_list = User.objects.all().exclude(pk=request.user.pk)
    if request.user.tipo_usuario == 'admin_tecnico':
        usuarios_list = usuarios_list.exclude(tipo_usuario__in=ADMIN_ROLES)
    usuarios_list = usuarios_list.order_by('tipo_usuario', 'last_name')
    
    context = {
        'titulo': 'Gestión de Usuarios',
        'usuarios': usuarios_list,
    }
    return render(request, 'administracion/admin_usuarios.html', context)


@login_required
@user_passes_test(is_admin_tecnico_or_super, login_url='/') 
def mantenimiento_logs(request):
    return render(request, 'administracion/mantenimiento_logs.html', {'titulo': 'Mantenimiento y Logs'})

@login_required
@user_passes_test(lambda u: u.tipo_usuario == 'super_admin', login_url='/') 
def configuracion_global(request):
    return render(request, 'administracion/configuracion_global.html', {'titulo': 'Configuración Global del Sistema'})


# VISTAS DE ADMINISTRACIÓN REGIONAL
@login_required
@user_passes_test(lambda u: u.tipo_usuario == 'admin_regional', login_url='/') 
def reportes_regionales(request):
    return render(request, 'administracion/reportes_regionales.html', {'titulo': 'Reportes Regionales'})

@login_required
@user_passes_test(lambda u: u.tipo_usuario == 'admin_regional', login_url='/') 
def monitoreo_comercios(request):
    return render(request, 'administracion/monitoreo_comercios.html', {'titulo': 'Monitoreo de Comercios'})


# --- NUEVAS VISTAS PARA GESTIÓN DE USUARIOS (EDICIÓN Y ESTADO) ---

@login_required
@user_passes_test(is_admin_tecnico_or_super, login_url='/') 
def usuario_editar(request, user_id):
    """Permite al Admin Técnico/Super Admin editar un usuario existente."""
    user_to_edit = get_object_or_404(User, pk=user_id)
    
    is_editing_admin = user_to_edit.tipo_usuario in ADMIN_ROLES

    if request.user.tipo_usuario == 'admin_tecnico' and is_editing_admin:
        messages.error(request, "El Administrador Técnico no tiene permisos para editar a otros administradores.")
        return redirect('admin_usuarios')
    
    if user_to_edit.tipo_usuario == 'super_admin' and request.user.tipo_usuario != 'super_admin':
        messages.error(request, "Solo un Super Administrador puede editar a otro Super Administrador.")
        return redirect('admin_usuarios')
    
    if user_to_edit.pk == request.user.pk:
        messages.error(request, "No puedes editar tu propio perfil desde este panel.")
        return redirect('admin_usuarios')
    if request.method == 'POST':
        form = PerfilEdicionForm(request.POST, instance=user_to_edit) 
        if form.is_valid():
            form.save()
            messages.success(request, f'Usuario **{user_to_edit.username}** actualizado exitosamente.')
            return redirect('admin_usuarios')
        else:
            messages.error(request, 'Error al guardar los cambios. Revisa los campos marcados.')
    else:
        form = PerfilEdicionForm(instance=user_to_edit)
    context = {
        'titulo': f'Editar Usuario: {user_to_edit.username}',
        'form': form,
        'user_to_edit': user_to_edit
    }
    return render(request, 'administracion/usuario_editar.html', context)


@login_required
@user_passes_test(is_admin_tecnico_or_super, login_url='/') 
def usuario_activar_desactivar(request, user_id, action):
    """Activa o desactiva la cuenta de un usuario."""
    user_to_change = get_object_or_404(User, pk=user_id)
    
    is_changing_admin = user_to_change.tipo_usuario in ADMIN_ROLES
    
    if request.user.tipo_usuario == 'admin_tecnico' and is_changing_admin:
        messages.error(request, "El Administrador Técnico no tiene permisos para modificar el estado de otros administradores.")
        return redirect('admin_usuarios')
    
    if user_to_change.tipo_usuario == 'super_admin' and request.user.tipo_usuario != 'super_admin':
        messages.error(request, "Solo un Super Administrador puede modificar el estado de otro Super Administrador.")
        return redirect('admin_usuarios')
    
    if user_to_change.pk == request.user.pk:
         messages.error(request, "No puedes modificar el estado de tu propia cuenta.")
         return redirect('admin_usuarios')

    if action == 'activar':
        user_to_change.is_active = True
        user_to_change.save()
        messages.success(request, f'La cuenta de {user_to_change.username} ha sido ACTIVADA.')
    elif action == 'desactivar':
        user_to_change.is_active = False
        user_to_change.save()
        messages.warning(request, f'La cuenta de {user_to_change.username} ha sido DESACTIVADA.')
    
    return redirect('admin_usuarios')