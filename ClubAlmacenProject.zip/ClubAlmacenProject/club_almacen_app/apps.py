from django.apps import AppConfig


class ClubAlmacenAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'club_almacen_app'
