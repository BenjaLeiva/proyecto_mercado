from django.contrib.auth.models import AbstractUser
from django.db import models

# --- CONSTANTES ---
TIPO_USUARIO_CHOICES = (
    ('comerciante', 'Comerciante'),
    ('proveedor', 'Proveedor'),
    ('admin_regional', 'Administrador Regional'),
    ('admin_tecnico', 'Administrador Técnico'),
    ('super_admin', 'Super Administrador'),
)

# --- MODELOS GEOGRÁFICOS ---

class Region(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Comuna(models.Model):
    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.nombre} ({self.region.nombre})"


# --- MODELO DE USUARIO PERSONALIZADO ---

class User(AbstractUser):
    """Modelo de Usuario Personalizado con roles y campos de negocio."""
    
    tipo_usuario = models.CharField(
        max_length=20,
        choices=TIPO_USUARIO_CHOICES,
        default='comerciante',
        verbose_name='Tipo de Usuario (Rol)'
    )

    business_name = models.CharField(
        max_length=255, 
        blank=True, 
        null=True, 
        verbose_name='Nombre del Negocio/Empresa'
    )
    business_category = models.CharField(
        max_length=100, 
        blank=True, 
        null=True, 
        verbose_name='Rubro o Categoría'
    )
    phone_number = models.CharField(
        max_length=15, 
        blank=True, 
        null=True, 
        verbose_name='Número de Teléfono'
    )

    # Campos de Ubicación (para Directorios/Filtrado)
    region = models.ForeignKey(
        Region, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        verbose_name='Región'
    )
    comuna = models.ForeignKey(
        Comuna, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        verbose_name='Comuna'
    )

    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'

    def get_full_name(self):
        return f"{self.first_name} {self.last_name}".strip()
    
    def get_tipo_usuario_display(self):
        return dict(TIPO_USUARIO_CHOICES).get(self.tipo_usuario, self.tipo_usuario)


# --- MODELOS DEL FORO (Añadidos para resolver el ImportError) ---

class TemaForo(models.Model):
    titulo = models.CharField(max_length=255)
    contenido = models.TextField()
    autor = models.ForeignKey(User, on_delete=models.CASCADE) 
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    imagen_promocional = models.ImageField(upload_to='foro/imagenes/', blank=True, null=True) 

    def __str__(self):
        return self.titulo

class RespuestaForo(models.Model):
    tema = models.ForeignKey(TemaForo, on_delete=models.CASCADE)
    autor = models.ForeignKey(User, on_delete=models.CASCADE) 
    contenido = models.TextField()
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Respuesta de {self.autor.username} a {self.tema.titulo[:20]}..."
    
class OfertaProveedor(models.Model):
    proveedor = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        limit_choices_to={'tipo_usuario': 'proveedor'},
        related_name='ofertas',
        verbose_name='Proveedor'
    )
    titulo = models.CharField(max_length=150)
    descripcion = models.TextField()
    precio_regular = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    precio_oferta = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_expiracion = models.DateField(help_text="Fecha hasta la cual la oferta es válida.")
    imagen_oferta = models.ImageField(upload_to='ofertas/', null=True, blank=True)
    fecha_publicacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.titulo} de {self.proveedor.business_name or self.proveedor.get_full_name()}"
        
    class Meta:
        verbose_name = "Oferta de Proveedor"
        verbose_name_plural = "Ofertas de Proveedores"

ESTADO_TICKET_CHOICES = (
    ('pendiente', 'Pendiente'),
    ('en_progreso', 'En Progreso'),
    ('cerrado', 'Cerrado'),
)

class TicketSoporte(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    asunto = models.CharField(max_length=255)
    descripcion = models.TextField()
    estado = models.CharField(max_length=20, choices=ESTADO_TICKET_CHOICES, default='pendiente')
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    # Podrías añadir un campo para el administrador asignado
    admin_asignado = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='tickets_gestionados'
    )

    def __str__(self):
        return f"Ticket {self.pk}: {self.asunto} ({self.get_estado_display()})"