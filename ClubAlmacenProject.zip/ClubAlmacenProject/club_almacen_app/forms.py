from django import forms
from .models import User, Comuna, Region, TIPO_USUARIO_CHOICES, TemaForo, RespuestaForo, OfertaProveedor, TicketSoporte

REGISTRO_CHOICES = [
    ('comerciante', 'Comerciante (Dueño de Almacén)'),
    ('proveedor', 'Proveedor de Productos'),
]

class RegistroUsuarioForm(forms.ModelForm):
    """Formulario para el registro inicial de comerciantes/proveedores."""
    
    region_aux = forms.ModelChoiceField(
        queryset=Region.objects.all().order_by('nombre'),
        label="Región",
        required=True,
        empty_label="Seleccione su Región",
        widget=forms.Select(attrs={'class': 'form-control', 'id': 'id_region_aux'}) 
    )

    password2 = forms.CharField(
        label='Confirmar Contraseña', 
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = User
        fields = [
            'first_name', 'last_name', 'email', 'username',
            'password', 'tipo_usuario', 
            'business_name', 'business_category', 'phone_number',
            'comuna', 
        ]
        widgets = {
            'password': forms.PasswordInput(attrs={'class': 'form-control'}),
            'tipo_usuario': forms.Select(choices=TIPO_USUARIO_CHOICES[:2], attrs={'class': 'form-control'}), 
            'email': forms.EmailInput(attrs={'required': True, 'class': 'form-control'}),
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'business_name': forms.TextInput(attrs={'class': 'form-control'}),
            'business_category': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'comuna': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'first_name': 'Nombre',
            'last_name': 'Apellido',
            'email': 'Email (Será su clave de acceso principal)',
            'username': 'Nombre de Usuario',
            'phone_number': 'Teléfono / WhatsApp',
            'tipo_usuario': 'Tipo de Socio',
            'business_name': 'Nombre del Negocio/Empresa',
            'business_category': 'Rubro/Categoría',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['comuna'].queryset = Comuna.objects.none()
        if 'region_aux' in self.data:
            try:
                region_id = self.data.get('region_aux')
                self.fields['comuna'].queryset = Comuna.objects.filter(region_id=region_id).order_by('nombre')
                
            except (ValueError, TypeError):
                pass
        elif self.instance.pk:
            self.fields['comuna'].queryset = self.instance.region.comuna_set.order_by('nombre')

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password2 = cleaned_data.get("password2")

        if password and password2 and password != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        user.region = self.cleaned_data.get('region_aux')
        
        if commit:
            user.save()
        return user


class PerfilEdicionForm(forms.ModelForm):
    """Formulario para editar la información del perfil del usuario (Acoplado a User)."""
    
    email = forms.EmailField(
        label='Correo Electrónico (No Editable)',
        required=True,
        widget=forms.TextInput(attrs={'readonly': 'readonly', 'class': 'form-control-plaintext'})
    )
    
    class Meta:
        model = User 
        fields = [
            'first_name', 'last_name', 'email', 'phone_number', 
            'business_name', 'business_category', 'region', 'comuna'
        ]
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        for field_name, field in self.fields.items():
            if field_name != 'email':
                field.widget.attrs.update({'class': 'form-control'})
            
        self.fields['region'].widget.attrs.update({'id': 'id_region_edit'})
        
        if self.instance and self.instance.region:
            region_actual = self.instance.region
            self.fields['comuna'].queryset = Comuna.objects.filter(region=region_actual).order_by('nombre')
        else:
            self.fields['comuna'].queryset = Comuna.objects.none() 

        self.fields['phone_number'].label = 'Teléfono / WhatsApp'
        self.fields['business_name'].label = 'Nombre del Negocio/Empresa'
        self.fields['business_category'].label = 'Rubro o Categoría'
        
    # --- MODIFICACIÓN CLAVE APLICADA AQUÍ ---
    def clean_comuna(self):
        """
        Asegura que la comuna enviada sea válida.
        Esto es necesario porque el queryset de Comuna se inicializa a None, 
        pero el valor se carga por AJAX en el cliente.
        """
        comuna = self.cleaned_data.get('comuna')
        region = self.cleaned_data.get('region') 

        if comuna and region:
            if comuna.region != region:
                raise forms.ValidationError("La comuna seleccionada no pertenece a la región indicada.")
        
        return comuna


# --- Formularios del Foro ---

class TemaForoForm(forms.ModelForm):
    class Meta:
        model = TemaForo
        fields = ['titulo', 'contenido', 'imagen_promocional'] 
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Título del tema'}),
            'contenido': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Escribe aquí tu contenido...'}),
        }

class RespuestaForoForm(forms.ModelForm):
    class Meta:
        model = RespuestaForo
        fields = ['contenido']
        widgets = {
            'contenido': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Escribe tu respuesta aquí...'}),
        }

class OfertaForm(forms.ModelForm):
    """Formulario para que un proveedor publique una nueva oferta."""
    class Meta:
        model = OfertaProveedor
        fields = ['titulo', 'descripcion', 'precio_regular', 'precio_oferta', 'fecha_expiracion', 'imagen_oferta']
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'precio_regular': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Precio sin oferta (Opcional)'}),
            'precio_oferta': forms.NumberInput(attrs={'class': 'form-control'}),
            'fecha_expiracion': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'imagen_oferta': forms.FileInput(attrs={'class': 'form-control'}),
        }
        labels = {
            'precio_regular': 'Precio Regular ($)',
            'precio_oferta': 'Precio de Oferta ($)',
            'fecha_expiracion': 'Fecha de Expiración',
            'imagen_oferta': 'Imagen Promocional',
        }

class AdminChoiceField(forms.ModelChoiceField):
    """
    ModelChoiceField personalizado para mostrar el nombre completo del administrador
    seguido de su tipo de usuario (rol).
    """
    def label_from_instance(self, obj):
        full_name = obj.get_full_name()
        
        role_display = obj.get_tipo_usuario_display() 
        
        return f"{full_name} ({role_display})"

class TicketForm(forms.ModelForm):
    # Campo para elegir el administrador
    admin_asignado = AdminChoiceField(
        # Filtramos para que solo muestre usuarios con roles de administrador
        queryset=User.objects.filter(tipo_usuario__in=['super_admin', 'admin_tecnico', 'admin_regional']),
        label='Dirigir a Administrador (Opcional)',
        required=False,
        empty_label="Seleccione un Administrador (Opcional)",
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = TicketSoporte
        fields = ['asunto', 'descripcion', 'admin_asignado']
        widgets = {
            'asunto': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Título del problema o consulta'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Describe detalladamente tu situación.'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Aplicar 'form-control' a los campos que no son ModelChoiceField
        for field_name, field in self.fields.items():
            if field_name not in ['admin_asignado']:
                field.widget.attrs.update({'class': 'form-control'})

class TicketGestionForm(forms.ModelForm):
    """Formulario para que los administradores gestionen el estado y la asignación."""
    
    admin_asignado = AdminChoiceField(
        queryset=User.objects.filter(tipo_usuario__in=['super_admin', 'admin_tecnico', 'admin_regional']),
        label='Reasignar a Administrador',
        required=False,
        empty_label="Seleccione un Administrador",
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = TicketSoporte
        fields = ['estado', 'admin_asignado']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-select'}),
        }